// 1. import data pet list
// 2. buat selector untuk element dropdown 
// 3. buat selector untuk element form 
// 4. buat selector untuk element search 
const dropdownElement = ...
const formElement = ...
const searchInputElement = ...
// 5. buat fungsi yang berisi komponen beserta data dengan template sebagai berikut
<div class="card my-3 mx-2" style="width: 20%">
    // 5a. isi src dengan photo.full
    <img height="300" style="object-fit: cover" class="card-img-top" src=... alt="Card image cap" />
    <div class="card-body">
      // 5b. nama pet
      <h5 class="card-title d-inline"></h5>
      // 5c. tipe
      <span class="badge badge-pill badge-info"></span>
      <p class="card-text">
        // 5d. deskripsi
      </p>
      // 5e. Tanggal di publikasikan
      <p><small>Published at: ...</small></p>
      <button
        type="button"
        class="btn btn-secondary"
        data-toggle="modal"
        data-target="#confirmationModal"
      >
        Adopt Me
      </button>
    </div>
  </div>

// 6. fungsi render komponen pet dengan map 
const renderComponent = ...

// 7. renderComponent dipanggil dengan parameter petList untuk menampilkan data (sebagai inisialisasi sebelum data difilter)

// 8. Lengkapi fungsi sortPetById 
const sortPetById = (key) => {
  if (key === "oldest") {
    // 8a. return sort berdasarkan tanggal masuk paling lama
  }
  if (key === "newest") {
   // 8b. return sort berdasarkan tanggal masuk paling baru
  }
  if (key === "name") {
    // 8a. return sort berdasarkan name
  }
};

// 9. Lengkapi fungsi untuk search pet berdasarkan key
const searchPetByKey = (key) => {
  
};

// 10. Buat event listener "change" untuk dropdown element dan tampilkan ketika memilih option pada dropdown
dropdownElement.addEventListener("change", (event) => {
  // 10a. gunakan value dari event untuk melakukan sort dari fungsi 8
  // 10b. panggil fungsi untuk menampilkan komponen dari hasil fungsi sort yang dipanggil pada poin 10a.
});

// 11. Sama seperti point 9, buat event listener "submit" dan tampilkan ketika user submit form
// 11a. gunakan value dari event untuk melakukan search dari fungsi 9
// 11b. panggil fungsi untuk menampilkan komponen dari hasil fungsi sort yang dipanggil pada poin 11a.